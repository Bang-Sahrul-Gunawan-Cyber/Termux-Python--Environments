clear
#pip install --upgrade pip
#pip install -r requirements.txt
pip2 install -r requirements.txt
